import HomePage from "./components/ui/home/HomePage";

export default function Home() {
  return (
    <div>
        <HomePage/>
    </div>
  );
}
